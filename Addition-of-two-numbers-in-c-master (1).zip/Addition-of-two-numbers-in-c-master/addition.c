#include<stdio.h>
#include<conio.h>

int main()
{
int a,b,c;
printf("Enter the two numbers\n");
scanf("%d%d",&a,&b);
c=a+b;
printf("Sum of numbers is %d",c);
return 0;
}
